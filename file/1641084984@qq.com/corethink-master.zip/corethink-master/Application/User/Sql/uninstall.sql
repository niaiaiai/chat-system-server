DROP TABLE IF EXISTS `oc_user_attribute`;
DROP TABLE IF EXISTS `oc_user_message`;
DROP TABLE IF EXISTS `oc_user_person`;
DROP TABLE IF EXISTS `oc_user_type`;
