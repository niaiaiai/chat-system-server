DROP TABLE IF EXISTS `oc_cms_article`;
DROP TABLE IF EXISTS `oc_cms_attribute`;
DROP TABLE IF EXISTS `oc_cms_index`;
DROP TABLE IF EXISTS `oc_cms_category`;
DROP TABLE IF EXISTS `oc_cms_type`;
DROP TABLE IF EXISTS `oc_cms_comment`;
DROP TABLE IF EXISTS `oc_cms_report`;
DROP TABLE IF EXISTS `oc_cms_mark`;
